"""Download pinned upstream font bytes and licenses for issue 143."""
from pathlib import Path
from urllib.request import urlopen
from urllib.parse import quote
import hashlib
import json

root = Path(__file__).resolve().parents[2]
out = root / 'assets/fonts/arabic'
out.mkdir(parents=True, exist_ok=True)
sources = [
 ('aliftype/amiri', '6331fc82b0d20d9439a0792e21a9294ca015a93f', 'fonts/Amiri-Regular.ttf', 'Amiri-Regular.ttf'),
 ('aliftype/amiri', '6331fc82b0d20d9439a0792e21a9294ca015a93f', 'fonts/Amiri-Bold.ttf', 'Amiri-Bold.ttf'),
 ('aliftype/amiri', '6331fc82b0d20d9439a0792e21a9294ca015a93f', 'OFL.txt', 'OFL-Amiri.txt'),
]
for weight in ['Regular', 'Medium', 'SemiBold', 'Bold']:
 sources.append(('IBM/plex', '763c36ef9117782905ae010056dfbe8fd2653a25', f'packages/plex-sans-arabic/fonts/complete/ttf/IBMPlexSansArabic-{weight}.ttf', f'IBMPlexSansArabic-{weight}.ttf'))
sources.append(('IBM/plex', '763c36ef9117782905ae010056dfbe8fd2653a25', 'LICENSE.txt', 'OFL-IBMPlex.txt'))
for folder, name, filename in [('reemkufi', 'ReemKufi', 'ReemKufi[wght].ttf'), ('cairo', 'Cairo', 'Cairo[slnt,wght].ttf')]:
 for path, dest in [(filename, name+'-Variable.ttf'), ('OFL.txt', 'OFL-'+name+'.txt')]:
  sources.append(('google/fonts', '9710da1eacb3be272583c3224dcb70f9da6eadbb', f'ofl/{folder}/{path}', dest))
manifest=[]
for repo, commit, path, dest in sources:
 url=f'https://raw.githubusercontent.com/{repo}/{commit}/{quote(path)}'
 data=urlopen(url).read()
 (out/dest).write_bytes(data)
 manifest.append(dict(file=dest, repository=repo, commit=commit, upstream_path=path, url=url, sha256=hashlib.sha256(data).hexdigest(), bytes=len(data)))
 print(dest, len(data))
(out/'provenance.json').write_text(json.dumps(manifest, indent=2)+'\n')
