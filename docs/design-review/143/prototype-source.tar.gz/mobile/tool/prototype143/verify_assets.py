"""Verify capture assets and numeric/font constraints without network access."""
from pathlib import Path
import hashlib
import json
import re
from fontTools.ttLib import TTFont

root=Path(__file__).resolve().parents[2]
manifest=json.loads((root/'assets/fonts/arabic/provenance.json').read_text())
for entry in manifest:
    data=(root/'assets/fonts/arabic'/entry['file']).read_bytes()
    assert hashlib.sha256(data).hexdigest()==entry['sha256'], entry['file']
    if entry['file'].endswith('.ttf'):
        font=TTFont(root/'assets/fonts/arabic'/entry['file'])
        print(entry['file'],font['name'].getDebugName(1),font['name'].getDebugName(5))
files=[root/'test/visual/arabic_143_capture_test.dart', root/'lib/src/core/arabic_prototype.dart']
files+=list((root/'lib/src/features/player/workout').glob('logger_*.dart'))
files+=[root/'lib/src/features/player/dashboard/dashboard_tab.dart',root/'lib/src/features/player/chat/chat_screen.dart']
for path in files:
    assert not re.search('[\u0660-\u0669\u06f0-\u06f9]',path.read_text()),path
fixture=(root/'test/visual/arabic_143_capture_test.dart').read_text()
arabic={ord(c) for c in fixture if '\u0600'<=c<='\u06ff'}
for entry in manifest:
    if entry['file'].endswith('.ttf'):
        assert arabic<=TTFont(root/'assets/fonts/arabic'/entry['file']).getBestCmap().keys(),entry['file']
print('PASS: pinned hashes, exact font names, Arabic fixture glyph coverage, no Arabic-Indic/Persian digits')
