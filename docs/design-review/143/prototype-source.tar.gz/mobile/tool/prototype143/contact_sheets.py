"""Compose comparison sheets from untouched Flutter PNG captures."""
from pathlib import Path
import os
from PIL import Image, ImageDraw, ImageFont

out = Path(os.environ.get('CAPTURE_OUT', '/mnt/work/MAYOS/docs/design-review/143/screens'))
review = out.parent
font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 17)
small = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 14)
cols = [('A', '360x640'), ('B', '360x640'), ('A', '412x915'), ('B', '412x915')]

def sheet(name, states):
    widths=[360,360,412,412]
    canvas=Image.new('RGB',(sum(widths)+5*20, len(states)*965+100),'#e4e7ec')
    draw=ImageDraw.Draw(canvas)
    draw.text((20,12), f'MAYOS #143 | {name} | font choice OPEN',font=font,fill='#101d2e')
    x=20
    for (pair,size),width in zip(cols,widths):
        family='Amiri / IBM Plex Sans Arabic' if pair=='A' else 'Reem Kufi / Cairo'
        draw.text((x,42),f'{pair}: {family}',font=small,fill='#101d2e')
        draw.text((x,65),size+' logical px | PNGs at 2x',font=small,fill='#101d2e')
        x+=width+20
    for row,(state,theme) in enumerate(states):
        y=100+row*965
        x=20
        for (pair,size),width in zip(cols,widths):
            draw.text((x,y),f'{state} | {theme}',font=font,fill='#101d2e')
            path=out/f'{pair}-{state}-{theme}-{size}.png'
            if path.exists():
                im=Image.open(path).convert('RGB')
                im=im.resize((width,int(size.split('x')[1])),Image.Resampling.LANCZOS)
                canvas.paste(im,(x,y+30))
            x+=width+20
    canvas.save(review/f'comparison-{name}.png')

for screen,detail in [('home','home-detail'),('logger','logger-keypad'),('chat','chat-detail')]:
    sheet(screen,[(state,theme) for state in [screen,detail] for theme in ['light','dark']])
sheet('logger-stress',[('logger-keypad-initial','light'),('logger-keypad-initial','dark'),('logger-rir','dark'),('logger-swipe','dark')])
