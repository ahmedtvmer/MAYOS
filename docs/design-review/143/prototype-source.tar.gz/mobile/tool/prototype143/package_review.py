"""Package the supplied mobile snapshot plus bounded prototype modifications."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

root=Path(__file__).resolve().parents[2]
baseline=Path(os.environ.get('BASELINE_MOBILE','/tmp/mayos-arabic-143-baseline/mobile'))
review=Path(os.environ.get('REVIEW_OUT','/mnt/work/MAYOS/docs/design-review/143'))
review.mkdir(parents=True,exist_ok=True)
# Only the supplied snapshot and new source/font/tool files enter this bundle.
files={p.relative_to(baseline) for p in baseline.rglob('*') if p.is_file()}
for folder in ['lib','test','tool','assets']:
    files|={p.relative_to(root) for p in (root/folder).rglob('*') if p.is_file()}
for rel in files:
    assert not any(x in rel.parts for x in ['.git','.dart_tool','build','.baseline-verification'])
    assert not rel.name.startswith('.env')
    assert rel.name not in ['local.properties','key.properties']
patch=[]
changes=[]
for rel in sorted(files):
    old=baseline/rel; new=root/rel
    before=old.read_bytes() if old.exists() else b''
    after=new.read_bytes()
    if before==after: continue
    path='mobile/'+str(rel)
    changes.append(dict(path=path, kind='modified' if old.exists() else 'added', sha256=hashlib.sha256(after).hexdigest()))
    result=subprocess.run(['git','diff','--no-index','--binary',str(old) if old.exists() else '/dev/null',str(new)],capture_output=True)
    assert result.returncode==1,result.stderr.decode()
    # Preserve CRLF and missing-final-newline metadata in upstream licenses.
    lines=result.stdout.decode().splitlines(keepends=True)
    lines[0]=f'diff --git a/{path} b/{path}\n'
    for index,line in enumerate(lines):
        if line.startswith('--- '): lines[index]='--- '+('a/'+path if old.exists() else '/dev/null')+'\n'
        if line.startswith('+++ '): lines[index]='+++ b/'+path+'\n'
    patch.extend(lines)
(review/'prototype.patch').write_text(''.join(patch))
(review/'source-changes.json').write_text(json.dumps(changes,indent=2)+'\n')
manifest={str(rel):hashlib.sha256((baseline/rel).read_bytes()).hexdigest() for rel in sorted(files) if (baseline/rel).exists()}
(review/'supplied-snapshot-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
def portable_metadata(info):
    info.uid=info.gid=0
    info.uname=info.gname=''
    info.mtime=0
    return info

with tarfile.open(review/'prototype-source.tar.gz','w:gz') as archive:
    for rel in sorted(files): archive.add(root/rel,arcname='mobile/'+str(rel),recursive=False,filter=portable_metadata)
shutil.copy(root/'assets/fonts/arabic/provenance.json',review/'font-provenance.json')
for src,dest in [('143-pub-get.log','pub-get.log'),('143-analyze.log','analyze.log'),('143-capture-A.log','capture-A.log'),('143-capture-B.log','capture-B.log'),('143-widget-tests.log','widget-tests.log'),('143-full-tests.log','full-tests-incomplete.log'),('143-baseline-tests.log','baseline-tests.log')]:
    (review/'logs').mkdir(exist_ok=True)
    shutil.copy(Path('/tmp')/src,review/'logs'/dest)
print(len(files),'source files;',len(changes),'prototype modifications;',len(list((review/'screens').glob('*.png'))),'screen PNGs')
