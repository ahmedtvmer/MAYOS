@Tags(<String>['capture'])
library;

import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mayos_mobile/src/app.dart';
import 'package:mayos_mobile/src/core/arabic_prototype.dart';
import 'package:mayos_mobile/src/core/api_client.dart';
import 'package:mayos_mobile/src/core/app_mode.dart';
import 'package:mayos_mobile/src/core/active_workout.dart';
import 'package:mayos_mobile/src/core/baselines.dart';
import 'package:mayos_mobile/src/core/chat_storage.dart';
import 'package:mayos_mobile/src/core/device_timezone.dart';
import 'package:mayos_mobile/src/core/theme/theme_mode_store.dart';
import 'package:mayos_mobile/src/core/token_store.dart';
import 'package:mayos_mobile/src/core/workout_storage.dart';
import 'package:mayos_mobile/src/providers.dart';

import '../support/fake_mayos_api.dart';

const _boundary = Key('arabic143.capture');
final _enabled = Platform.environment['CAPTURE'] == '1';
const _day = 'الجزء العلوي: الظهر والكتف والذراع';
const _input =
    'عملت \u20663 × 10\u2069 في \u2066Wide-Grip Lat Pulldown\u2069 بوزن \u206627.5\u00a0kg\u2069. أرتاح قد إيه؟';
const _reply = '## الراحة بين المجموعات\n'
    'استرح لمدة \u206602:00\u2069 قبل المجموعة التالية. سجّل الوزن والتكرارات كما أديتها.\n\n'
    '> التكرارات المتبقية \u2066RIR\u00a02\u2069 تعني أنك تستطيع أداء تكرارين إضافيين.\n\n'
    '**آخر مجموعة:** \u206627.5\u00a0kg · 10\u00a0reps · RIR\u00a02\u2069';
const _english = 'Should I log bench press as 3 × 10 at 27.5\u00a0kg?';
const _answer =
    'نعم، سجّل كل مجموعة على حدة. اكتب \u206627.5\u00a0kg\u2069 و\u206610\u2069 تكرارات، ثم اختر قيمة \u2066RIR\u2069.';

FakeMayosApi _fixture() {
  final fake = FakeMayosApi()
    ..issuedToken = 'token-alice'
    ..currentUsername = 'alice'
    ..tokenValid = true
    ..profileExists = true
    ..programVersion = 1
    ..recoveryEmail = 'alice@example.com'
    ..scheduleEmpty = true
    ..volumeByDays = {
      7: {'الصدر': 12.5, 'الظهر والكتف الخلفي': 9.0}
    };
  fake.programDaysOverride = [
    {
      'day_name': _day,
      'day_order': 1,
      'warmup_exercises': <Map<String, dynamic>>[],
      'exercises': [
        for (final item in [
          ('lat_pulldown', 'Wide-Grip Lat Pulldown'),
          ('bench_press', 'Bench Press'),
        ])
          {
            'exercise_id': item.$1,
            'exercise_name': item.$2,
            'warmup_sets': 0,
            'target_sets': 3,
            'target_reps_min': 10,
            'target_reps_max': 10,
            'target_rpe': 8.0,
            'rest_seconds': 120,
            'notes': null,
          },
      ],
    },
  ];
  for (final (index, role, content) in [
    (1, 'user', _input),
    (2, 'assistant', _reply),
    (3, 'user', _english),
    (4, 'assistant', _answer),
  ]) {
    fake.chatHistory.add({
      'id': 'synthetic-$index',
      'role': role,
      'content': content,
      'created_at': '2026-10-01T10:00:0${index}Z',
    });
  }
  return fake;
}

Future<void> _loadFonts() async {
  final files = <String, List<String>>{
    'PlayfairDisplay': ['assets/fonts/PlayfairDisplay-Variable.ttf'],
    'Inter': ['assets/fonts/Inter-Variable.ttf'],
    'MaterialIcons': ['fonts/MaterialIcons-Regular.otf'],
    'Amiri': [
      'assets/fonts/arabic/Amiri-Regular.ttf',
      'assets/fonts/arabic/Amiri-Bold.ttf'
    ],
    'IBMPlexSansArabic': [
      for (final weight in ['Regular', 'Medium', 'SemiBold', 'Bold'])
        'assets/fonts/arabic/IBMPlexSansArabic-$weight.ttf'
    ],
    'ReemKufi': ['assets/fonts/arabic/ReemKufi-Variable.ttf'],
    'Cairo': ['assets/fonts/arabic/Cairo-Variable.ttf'],
  };
  for (final entry in files.entries) {
    final loader = FontLoader(entry.key);
    for (final file in entry.value) {
      loader.addFont(rootBundle.load(file));
    }
    await loader.load();
  }
}

Future<void> _ready(WidgetTester tester, Finder finder) async {
  for (int i = 0; i < 80; i++) {
    await tester.pump(const Duration(milliseconds: 100));
    if (finder.evaluate().isNotEmpty) {
      await tester.pump(const Duration(milliseconds: 400));
      expect(tester.takeException(), isNull);
      return;
    }
  }
  expect(finder, findsWidgets);
}

Future<void> _pumpApp(WidgetTester tester, ThemeMode mode) async {
  final tokens = InMemoryTokenStore();
  await tokens.save('token-alice');
  final chat = InMemoryChatCacheStore();
  await chat.writeDisclosureAccepted('account-alice');
  final fake = _fixture();
  await tester.pumpWidget(RepaintBoundary(
    key: _boundary,
    child: ProviderScope(overrides: [
      tokenStoreProvider.overrideWithValue(tokens),
      appModeStoreProvider.overrideWithValue(InMemoryAppModeStore()),
      themeModeStoreProvider.overrideWithValue(InMemoryThemeModeStore(mode)),
      draftStoreProvider.overrideWithValue(InMemoryDraftStore()),
      activeWorkoutStoreProvider
          .overrideWithValue(InMemoryActiveWorkoutStore()),
      baselineCacheStoreProvider
          .overrideWithValue(InMemoryBaselineCacheStore()),
      workoutCacheStoreProvider.overrideWithValue(InMemoryWorkoutCacheStore()),
      chatCacheStoreProvider.overrideWithValue(chat),
      clockProvider.overrideWithValue(() => DateTime.utc(2026, 10, 1, 10)),
      deviceTimezoneProvider.overrideWithValue(Future.value('UTC')),
      deviceTimezoneOrNullProvider.overrideWithValue(Future.value('UTC')),
      apiClientProvider.overrideWith((ref) {
        final client = ApiClient(
            tokens: ref.watch(tokenStoreProvider),
            baseUrl: 'http://test.local',
            adapter: fake.adapter);
        client.onUnauthorized = ref.watch(unauthorizedEventsProvider).signal;
        return client;
      }),
    ], child: const MayosApp()),
  ));
  await _ready(tester, find.text('ابدأ التمرين'));
  final context = tester.element(find.byType(MaterialApp));
  await tester.runAsync(() async {
    for (final variant in ['white', 'black']) {
      await precacheImage(
          AssetImage('assets/brand/mayos-mark-$variant.png'), context);
    }
  });
  await tester.pump();
}

Future<void> _capture(WidgetTester tester, String name) async {
  for (int i = 0; i < 5; i++) {
    await tester.pump(const Duration(milliseconds: 100));
  }
  expect(tester.takeException(), isNull, reason: 'No layout errors in $name');
  final boundary =
      tester.renderObject<RenderRepaintBoundary>(find.byKey(_boundary));
  await tester.runAsync(() async {
    final out = Directory(Platform.environment['CAPTURE_OUT'] ??
        '/mnt/work/MAYOS/docs/design-review/143/screens');
    await out.create(recursive: true);
    final image = await boundary.toImage(pixelRatio: 2);
    final data = (await image.toByteData(format: ui.ImageByteFormat.png))!;
    await File('${out.path}/$arabicPair-$name.png')
        .writeAsBytes(data.buffer.asUint8List());
    image.dispose();
  });
}

void _westernDigits(WidgetTester tester) {
  final forbidden = RegExp(r'[\u0660-\u0669\u06f0-\u06f9]');
  for (final text in tester.widgetList<Text>(find.byType(Text))) {
    expect(forbidden.hasMatch(text.data ?? text.textSpan?.toPlainText() ?? ''),
        isFalse);
  }
  for (final content in [_day, _input, _reply, _english, _answer]) {
    expect(forbidden.hasMatch(content), isFalse);
  }
}

void _keyOrder(WidgetTester tester) {
  for (final row in [
    ['1', '2', '3'],
    ['4', '5', '6'],
    ['7', '8', '9']
  ]) {
    final xs = [
      for (final digit in row)
        tester.getCenter(find.byKey(ValueKey('logger.key.$digit'))).dx
    ];
    expect(xs[0], lessThan(xs[1]));
    expect(xs[1], lessThan(xs[2]));
  }
  expect(
      tester.getCenter(find.byKey(const ValueKey('logger.key.dot'))).dx,
      lessThan(
          tester.getCenter(find.byKey(const ValueKey('logger.key.0'))).dx));
  expect(
      tester.getCenter(find.byKey(const ValueKey('logger.key.0'))).dx,
      lessThan(tester
          .getCenter(find.byKey(const ValueKey('logger.key.backspace')))
          .dx));
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(_loadFonts);
  for (final size in [const Size(360, 640), const Size(412, 915)]) {
    for (final mode in [ThemeMode.light, ThemeMode.dark]) {
      final suffix =
          '${mode.name}-${size.width.toInt()}x${size.height.toInt()}';
      testWidgets('actual Arabic home and logger $suffix', (tester) async {
        expect(arabicPrototype, isTrue);
        tester.view.physicalSize = size * 2;
        tester.view.devicePixelRatio = 2;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        await _pumpApp(tester, mode);
        _westernDigits(tester);
        await _capture(tester, 'home-$suffix');
        await tester.drag(find.byType(ListView).first, const Offset(0, -500));
        await tester.pump(const Duration(milliseconds: 400));
        await _capture(tester, 'home-detail-$suffix');
        await tester.drag(find.byType(ListView).first, const Offset(0, 1000));
        await tester.pump(const Duration(milliseconds: 400));
        await tester.ensureVisible(find.text('ابدأ التمرين'));
        await tester.tap(find.text('ابدأ التمرين'));
        await _ready(tester, find.byKey(const ValueKey('logger.cell.0.0.kg')));
        await _capture(tester, 'logger-$suffix');
        await tester.tap(find.byKey(const ValueKey('logger.cell.0.0.kg')));
        await _ready(tester, find.byKey(const ValueKey('logger.key.1')));
        _keyOrder(tester);
        for (final digit in ['2', '7', '.', '5']) {
          await tester.tap(find.byKey(
              ValueKey(digit == '.' ? 'logger.key.dot' : 'logger.key.$digit')));
          await tester.pump();
        }
        _westernDigits(tester);
        expect(find.text('27.5'), findsWidgets);
        if (size.width == 360) {
          await _capture(tester, 'logger-keypad-initial-$suffix');
        }
        // Show the same manual scroll a player can use after the existing
        // reveal logic misses a row behind the short-phone keypad.
        await tester
            .ensureVisible(find.byKey(const ValueKey('logger.cell.0.0.kg')));
        await tester.pump(const Duration(milliseconds: 400));
        await _capture(tester, 'logger-keypad-$suffix');
        await tester.tap(find.byKey(const ValueKey('logger.key.hide')));
        await tester.pump(const Duration(milliseconds: 400));
        await tester
            .ensureVisible(find.byKey(const ValueKey('logger.cell.0.0.rir')));
        await tester.tap(find.byKey(const ValueKey('logger.cell.0.0.rir')));
        await _ready(tester, find.byKey(const ValueKey('logger.rir.0')));
        expect(
            tester.getCenter(find.byKey(const ValueKey('logger.rir.0'))).dx,
            lessThan(tester
                .getCenter(find.byKey(const ValueKey('logger.rir.5')))
                .dx));
        if (size.width == 412 && mode == ThemeMode.dark) {
          await _capture(tester, 'logger-rir-$suffix');
        }
        await tester.tap(find.byKey(const ValueKey('logger.key.hide')));
        await tester.pump(const Duration(milliseconds: 400));
        if (size.width == 412 && mode == ThemeMode.dark) {
          final row = find.byKey(const ValueKey('logger.row.0.0'));
          await tester.ensureVisible(row);
          final gesture = await tester.startGesture(tester.getCenter(row));
          await gesture.moveBy(const Offset(20, 0));
          await tester.pump();
          await gesture.moveBy(const Offset(90, 0));
          await tester.pump();
          await _capture(tester, 'logger-swipe-$suffix');
          await gesture.cancel();
          await tester.pump(const Duration(milliseconds: 400));
        }
        await tester.pumpWidget(const SizedBox());
        await tester.pump();
      }, skip: !_enabled);
      testWidgets('actual Arabic mixed chat $suffix', (tester) async {
        tester.view.physicalSize = size * 2;
        tester.view.devicePixelRatio = 2;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        await _pumpApp(tester, mode);
        await tester.tap(find.byIcon(Icons.chat_bubble_outline));
        await _ready(tester, find.text(_input));
        _westernDigits(tester);
        await _capture(tester, 'chat-$suffix');
        await tester.drag(
            find.byType(CustomScrollView).first, const Offset(0, -250));
        await tester.pump(const Duration(milliseconds: 400));
        await _capture(tester, 'chat-detail-$suffix');
        await tester.pumpWidget(const SizedBox());
        await tester.pump();
      }, skip: !_enabled);
    }
  }
}
