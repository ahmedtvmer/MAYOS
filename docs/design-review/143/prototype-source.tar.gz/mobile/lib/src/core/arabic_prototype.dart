import 'package:flutter/widgets.dart';

/// Disposable #143 typography review. No account language preference is wired.
const String arabicPair = String.fromEnvironment('ARABIC_PAIR');
const bool arabicPrototype = arabicPair == 'A' || arabicPair == 'B';

/// Isolate conventional numeric / English gym strings inside Arabic sentences.
String prototypeLtr(String value) {
  if (!arabicPrototype) return value;
  final keptTogether = value.replaceAllMapped(
    RegExp(r'(\d[\d.]*) (kg|reps)\b'),
    (match) => '${match[1]}\u00a0${match[2]}',
  );
  return '\u2066$keptTogether\u2069';
}

/// Choose paragraph direction from the first strong letter, not account UI.
TextDirection prototypeMessageDirection(String value) {
  final String? letter =
      RegExp(r'[A-Za-z\u0621-\u063a\u0641-\u064a]').firstMatch(value)?[0];
  return letter != null && letter.codeUnitAt(0) > 127
      ? TextDirection.rtl
      : TextDirection.ltr;
}

/// Translate only the logger's existing computed caption clauses for review.
String prototypeGymCaption(String value) {
  if (!arabicPrototype) return value;
  return value.split(' · ').map((clause) {
    final sets = RegExp(r'^(\d+) sets?$').firstMatch(clause);
    if (sets != null) return '${prototypeLtr(sets[1]!)} مجموعات';
    final reps = RegExp(r'^([\d–]+) reps$').firstMatch(clause);
    if (reps != null) return '${prototypeLtr(reps[1]!)} تكرارات';
    if (clause.startsWith('Rest ')) {
      return 'راحة ${prototypeLtr(clause.substring(5))}';
    }
    if (clause.startsWith('Last: ')) {
      return 'السابق: ${prototypeLtr(clause.substring(6))}';
    }
    return prototypeLtr(clause);
  }).join(' · ');
}
